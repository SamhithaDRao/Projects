const product = [
    id=0,
    Name="Toothbrush 1",
    price=100,
    instock=100,
    description="abc",
    imgSrc="./brush.png",
}
]