const productsE1=document.querySelector(".products");
function renderProducts(){
    products.forEach((product)=>
    )
}