<?php
$fullname=$_POST['fullname'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$password=$_POST['password'];


$conn = new mysqli('localhost','root','','','test');
if($conn->connect_error)
{
    die('Connection failed:'.$conn->connect_error);
}
else 
{
    $stmt=$conn->prepare("insert into registration(fullname,email,phone,password)
    values(?,?,?,?)");
    $stmt->blind_param("ssis",$fullname,$email,$phone,$password);
    $stmt->execute();
    echo "registration successful";
    $stmt->close();
    $conn->close();
}
?>